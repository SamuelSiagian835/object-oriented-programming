package fintech.model;

/**
 * @author NIM Nama
 * @author NIM Nama
 */
public class Transaction {

    // class definition

}