package fintech.model;

/**
 * @author NIM Nama
 * @author NIM Nama
 */
public class Account {

    // class definition

}